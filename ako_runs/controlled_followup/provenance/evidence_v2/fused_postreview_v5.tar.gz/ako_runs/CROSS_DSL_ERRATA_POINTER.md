# Controlled cross-DSL report correction pointer

The historical controlled cross-DSL report and review are preserved byte-for-byte.
Their post-review corrections and completed follow-up evidence are maintained in
the append-only overlays:

- [`controlled_followup/ERRATA_20260730.md`](controlled_followup/ERRATA_20260730.md)
- [`controlled_followup/REVIEW_RESPONSE_20260730.md`](controlled_followup/REVIEW_RESPONSE_20260730.md)
- [`controlled_followup/REVIEW_ROUND2_20260730.md`](controlled_followup/REVIEW_ROUND2_20260730.md)
- [`controlled_followup/robust_gate/audits/matmul_v4_instrument_v1/results/summary.json`](controlled_followup/robust_gate/audits/matmul_v4_instrument_v1/results/summary.json)

The overlays correct scope, provenance, artifact-version, robustness, and
matmul-v4 legality interpretations without rewriting the historical reports.
