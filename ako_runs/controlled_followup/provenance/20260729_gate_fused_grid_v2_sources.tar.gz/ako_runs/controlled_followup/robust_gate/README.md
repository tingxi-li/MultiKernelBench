# Robust correctness-gate campaign

This subtree is an isolated follow-up to the completed Phase 1 and Phase 2
campaigns. It does not edit or import their result files, and importing this
package does not initialize CUDA or compile a kernel.

The campaign separates two questions:

1. `semantic_q32` / `semantic_mixed`: is the output close to fp64 evaluation of
   the original fp32 inputs at the named quality tier?
2. `conformance_mixed`: does the implementation realize its declared fp16/fp32
   rounding boundaries?

The legacy `1e-4 + 1e-4*abs(ref)` predicate is not used to freeze these gates.
It is inadequate in opposite directions for the studied operations: it is
distribution-dependent for matmul, weak at softmax probability scale, and can
reject correctly rounded fp16 SDPA storage.

## Frozen protocol

- Calibration: 32 domain-separated seeds per registered distribution and
  anchor.
- Tuning/smoke: 8 separate seeds.
- Locked validation: 64 separate seeds per distribution.
- Performance inputs: 3 separate seeds; performance statistics are outside
  this package.
- Each gate uses at least two named anchors. Candidate output is never used to
  set a threshold.
- A calibrated threshold is
  `next_1_2_5(1.25 * maximum_anchor_metric)` unless a larger preregistered
  minimum is present.
- Fixed structural thresholds, including non-finite and negative-probability
  counts, are zero.
- A candidate passes only if every metric passes on every registered case and
  all 64 validation seeds. Missing records, duplicate records, wrong seeds,
  collection errors, shape mismatches, empty tensors, non-floating tensors,
  NaN, and Inf fail closed.
- Zero failures among 64 independent validation seeds gives a one-sided 95%
  upper bound of about 4.6% on seed-level failure probability. Tensor elements
  are not treated as independent observations.

The operation-specific gate metrics are:

| Operation | Calibrated metrics | Fixed checks |
|---|---|---|
| Matmul | maximum absolute error, NRMSE, absolute signed bias, componentwise backward error | no non-finite values |
| Fused exact-erf GELU-softmax | maximum absolute error, NRMSE, row-sum error, row total variation, square-root Jensen-Shannon distance, probability-scaled maximum error | no non-finite or negative probabilities |
| SDPA | maximum absolute error, NRMSE, per-query relative L2, cosine distance, per-query scaled maximum error | no non-finite values |

The full distribution matrix, arithmetic contracts, shapes, and exact split
sizes are in [`manifest.json`](manifest.json). Its interchange contract and the
generated gate contract are in [`schemas/manifest.schema.json`](schemas/manifest.schema.json)
and [`schemas/gate_spec.schema.json`](schemas/gate_spec.schema.json).

## CPU tests

From the repository root:

```bash
python -m unittest discover \
  -s ako_runs/controlled_followup/robust_gate/tests \
  -p 'test_*.py' -v
```

The tests cover seed golden vectors and domain separation, strict JSON,
distribution invariants, fp16 rounding boundaries, hand-computed matmul and
SDPA oracles, SDPA metamorphic invariants, the softmax total-variation
pathology, fail-closed metric preflight, calibration coverage, and both passing
and deliberately failing validation candidates.

## Resolve and pin seeds

```bash
python -m ako_runs.controlled_followup.robust_gate.seeds \
  --manifest ako_runs/controlled_followup/robust_gate/manifest.json \
  --out /tmp/robust_gate_seeds.json
```

Every seed is derived from the NUL-separated tuple
`(namespace, op, case, split, tensor, index)` with SHA256. Tensor streams are
independent, so changing construction order cannot perturb existing operands.

## Short CPU matmul smoke test

The following intentionally uses only two seeds and `--allow-incomplete`. It
tests plumbing; its gate spec is **not eligible for a campaign freeze**.

```bash
python -m ako_runs.controlled_followup.robust_gate.collect \
  --manifest ako_runs/controlled_followup/robust_gate/manifest.json \
  --op matmul --gate semantic_q32 --split calibration \
  --candidate anchor --cpu-smoke --max-seeds 2 \
  --out /tmp/robust_gate_calibration.jsonl

python -m ako_runs.controlled_followup.robust_gate.calibrate \
  --manifest ako_runs/controlled_followup/robust_gate/manifest.json \
  --records /tmp/robust_gate_calibration.jsonl \
  --op matmul --gate semantic_q32 --allow-incomplete \
  --out /tmp/robust_gate_spec.json

python -m ako_runs.controlled_followup.robust_gate.collect \
  --manifest ako_runs/controlled_followup/robust_gate/manifest.json \
  --op matmul --gate semantic_q32 --split validation \
  --candidate exact --candidate-name cpu-exact \
  --cpu-smoke --max-seeds 2 \
  --out /tmp/robust_gate_validation.jsonl

python -m ako_runs.controlled_followup.robust_gate.validate \
  --manifest ako_runs/controlled_followup/robust_gate/manifest.json \
  --gate-spec /tmp/robust_gate_spec.json \
  --records /tmp/robust_gate_validation.jsonl \
  --allow-incomplete --out /tmp/robust_gate_summary.json
```

## Full calibration and freeze

Omit `--cpu-smoke`, `--max-seeds`, and `--allow-incomplete`. A full matmul
calibration against the manifest shape starts with:

```bash
python -m ako_runs.controlled_followup.robust_gate.collect \
  --manifest ako_runs/controlled_followup/robust_gate/manifest.json \
  --op matmul --gate semantic_q32 --split calibration \
  --candidate anchor --device cuda \
  --out ako_runs/controlled_followup/robust_gate/results/calibration/matmul_semantic_q32.jsonl

python -m ako_runs.controlled_followup.robust_gate.calibrate \
  --manifest ako_runs/controlled_followup/robust_gate/manifest.json \
  --records ako_runs/controlled_followup/robust_gate/results/calibration/matmul_semantic_q32.jsonl \
  --op matmul --gate semantic_q32 \
  --out ako_runs/controlled_followup/robust_gate/gate_spec.json
```

Long collections may be sharded with `--seed-start`, `--max-seeds`, and
`--cases`. Pass `--records` repeatedly to calibration or validation to consume
multiple JSONL shards. Strict calibration verifies every expected
`anchor × case × seed` tuple before emitting a gate.

`gate_spec.json` is intentionally not checked in by this scaffold: it must be
the output of the complete calibration evidence. A launch lock should bind at
least `campaign_id`, `manifest_sha256`, `calibration_records_sha256`, and the
SHA256 of the exact gate spec.

## Candidate adapters

Built-in candidates (`exact`, `zeros`, `row_reverse`, `native_fp32`, and
`native_mixed`) exist for testing. GPU kernels are loaded only when explicitly
requested:

```bash
python -m ako_runs.controlled_followup.robust_gate.collect \
  --manifest ako_runs/controlled_followup/robust_gate/manifest.json \
  --op matmul --gate semantic_q32 --split validation \
  --candidate callable --candidate-name tilelang-D-robust \
  --callable package.module:function --device cuda \
  --out candidate.jsonl
```

The callable receives keyword arguments `op`, `inputs`, `case`, and `contract`
and returns one tensor. It must not mutate the supplied inputs. The collector
records its source SHA256, exact seed map, manifest hash, shape, contract,
metrics, output dtype, and collection failures.

